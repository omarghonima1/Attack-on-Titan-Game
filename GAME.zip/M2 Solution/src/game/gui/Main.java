package game.gui;
	
import java.util.ArrayList;
import java.util.PriorityQueue;

import game.engine.weapons.*;
import game.engine.Battle;
import game.engine.exceptions.InsufficientResourcesException;
import game.engine.exceptions.InvalidLaneException;
import game.engine.lanes.Lane;
import game.engine.titans.*;
import game.engine.weapons.Weapon;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

public class Main extends Application {
	
	private Battle battle ;
	
	
	private Button PassTurn;
	private Button PlayGame;
	private Button About;
	private RadioButton EASY;
	private RadioButton HARD;
	private Button WeaponShop;
	private Button backplay;
	private VBox weaponbox;
	private Scene previousScene;
	private AnchorPane invalidlane;
	private Button back;
	private Button PiercingCannon;
	private Button WallTrap;
	private Button SniperCannon;
	private Button VolleySpreadCannon;
	private Button weaponButton;
	private Scene easyScene;
	private Scene hardScene;
	private Scene AboutScene;
	private Scene WeaponScene;
	private Scene GameOverScene;
	private AnchorPane WeaponPage;
	private AnchorPane Home;
	private AnchorPane EasyPage;
	private AnchorPane HardPage;
	private AnchorPane GameOver;
	private int z;
	private int y;
	
	private VBox[] wallbox; 

	private ComboBox<String> lanechoice;
	private Label desc;
	private Label score;
	private Label resources;
	private Label phase;
	private Label turn;
	private VBox info;
	private VBox over;
	private Label [] Wallnum;
	private Label  [] health;
	private Label [] danger;
	private Pane [] lanes;
	private String laneforweapon;
	private VBox [] WeaponImage;
	private AnchorPane insufficientresources;
	private Scene insufficientresourcesscene;
	private Scene invalidlanescene;
	private AnchorPane AboutPage;
	
	
	
	public void battleHander(Battle battle){
		for(int i=0;i<battle.getOriginalLanes().size();i++){
			
			
			
			
			
			if(!battle.getOriginalLanes().get(i).isLaneLost()){
				
				lanes[i+1].getChildren().clear();
				health[i+1].setText("Health= " + battle.getOriginalLanes().get(i).getLaneWall().getCurrentHealth());
				danger[i+1].setText("danger= " + battle.getOriginalLanes().get(i).getDangerLevel());
				
				WeaponImage[i+1].getChildren().clear();
				for(int k=0; k<battle.getOriginalLanes().get(i).getWeapons().size();k++){
			
					WeaponImage[i+1].getChildren().add(weaponHandler(battle.getOriginalLanes().get(i).getWeapons().get(k)));
					
					
						
					
					
				}
			
			
				
				for(Titan titan : battle.getOriginalLanes().get(i).getTitans()){

					
					StackPane titanStackPane = new StackPane();
					ProgressBar titanHealthBar = new ProgressBar();
					titanHealthBar.setProgress((double)titan.getCurrentHealth()/titan.getBaseHealth());
					titanHealthBar.setStyle("-fx-accent: red;");
					
					titanHealthBar.setPrefHeight(2);
					titanHealthBar.setPrefWidth(100);
					
			
					titanStackPane.setLayoutX(titan.getDistance());
					titanStackPane.setLayoutY(Math.random()*25);
					

					titanStackPane.getChildren().add(titanHandler(titan.getDangerLevel()));
					titanStackPane.getChildren().add(titanHealthBar);
					StackPane.setAlignment(titanHealthBar, Pos.BOTTOM_CENTER);
			
					lanes[i+1].getChildren().add(titanStackPane);
				}
			}
			else{
				lanes[i+1].getChildren().clear();
				WeaponImage[i+1].getChildren().clear();
				health[i+1].setText("Wall Lost");
				
			}
			
			
			
		}
	}
	
	public ImageView titanHandler(int code){
		Image pureTitanpng = new Image("puretitan.png");
        ImageView pureTitanImage = new ImageView(pureTitanpng);
        
        Image abnormalTitanpng = new Image("abormal.png");
        ImageView abnormalTitanImage = new ImageView(abnormalTitanpng);
        
        Image armoredTitanpng = new Image("armored.png");
        ImageView armoredTitanImage = new ImageView(armoredTitanpng);
        
        
        Image colossalTitanpng = new Image("collasel.png");
        ImageView colossalTitanImage = new ImageView(colossalTitanpng);
        
        
        if(code == 1)
        	return  pureTitanImage;
        else if(code == 2)
        	return abnormalTitanImage; 
        else if(code == 3)
        	return armoredTitanImage; 
        else
            return colossalTitanImage; 
	}

	public ImageView weaponHandler(Weapon w){
		if(w instanceof PiercingCannon){
			ImageView iv= new ImageView("PiercingCannon.jpeg");
			
			return iv;
		}
		if(w instanceof SniperCannon){
			ImageView iv= new ImageView("SniperCannon.png");
			return iv;
		}
		if(w instanceof WallTrap){
			ImageView iv= new ImageView("WallTrap.jpeg");
			return iv;
		}
		if(w instanceof VolleySpreadCannon){
			ImageView iv= new ImageView("VolleySpreadCannon.jpg");
			return iv;
		}
		
		return null;
		
	}
	
    public void weaponHandler(int code, String lane){
    	Stage alert = new Stage();
   
        VBox InsufExcep = new VBox();
        VBox InvalidLaneVbox = new VBox();
        
        
        Label NotEnough = new Label("Not Enough Resources");
        NotEnough.setStyle("-fx-font-size: 30px;");
        
        
        Label InvalidLane = new Label("Please choose another lane ");
        InvalidLane.setStyle("-fx-font-size: 30px;");
        
        
        InsufExcep.getChildren().addAll(NotEnough);
        InvalidLaneVbox.getChildren().addAll(InvalidLane);
        
        AnchorPane invalidlane = new AnchorPane();
        AnchorPane insufficientresources = new AnchorPane();
        InsufExcep.setAlignment(Pos.CENTER);
        InsufExcep.setAlignment(Pos.CENTER);
        
        adder(insufficientresources,InsufExcep,0,0,500,500);
        adder(invalidlane,InvalidLaneVbox,300,400,500,500);
        insufficientresourcesscene = new Scene(insufficientresources,800,800);
        invalidlanescene = new Scene(invalidlane,800,800);
        
       
    	
		if(lane== "Lane 1")
			try {
				
				battle.purchaseWeapon(code, battle.getOriginalLanes().get(0));
			} catch (InsufficientResourcesException e){
				alert.setScene(insufficientresourcesscene);
				alert.show();
			}
		catch (InvalidLaneException e){
			alert.setScene(invalidlanescene);
			alert.show();
		}
		
		catch (Exception e1) {
				
				e1.printStackTrace();
			}
    	if(lane== "Lane 2")
			try {
				battle.purchaseWeapon(code, battle.getOriginalLanes().get(1));
			} catch (InsufficientResourcesException e){
				alert.setScene(insufficientresourcesscene);
				alert.show();
			}
				catch (InvalidLaneException e){
					alert.setScene(invalidlanescene);
					alert.show();
				}
    		
    			catch (Exception e1) {
				
				e1.printStackTrace();
			}
    	
    	if(lane== "Lane 3")
			try {
				battle.purchaseWeapon(code, battle.getOriginalLanes().get(2));
			}catch (InsufficientResourcesException e){
				alert.setScene(insufficientresourcesscene);
				alert.show();
			}
			catch (InvalidLaneException e){
			alert.setScene(invalidlanescene);
			alert.show();
			}
    		
    		catch (Exception e1) {
				
				e1.printStackTrace();
			}
    	if(lane== "Lane 4")
			try {
				battle.purchaseWeapon(code, battle.getOriginalLanes().get(3));
			} catch (InsufficientResourcesException e){
				alert.setScene(insufficientresourcesscene);
				alert.show();
				}
			catch (InvalidLaneException e){
			alert.setScene(invalidlanescene);
			alert.show();
				}
    	
    		
    		catch (Exception e1) {
				
				e1.printStackTrace();
			}
    	if(lane== "Lane 5")
			try {
				battle.purchaseWeapon(code, battle.getOriginalLanes().get(4));
			} catch (InsufficientResourcesException e){
				alert.setScene(insufficientresourcesscene);
				alert.show();
			}
			catch (InvalidLaneException e){
			alert.setScene(invalidlanescene);
			alert.show();
			}
    		
    		catch (Exception e1) {
				
				e1.printStackTrace();
			}
		
	}
	
	public void adder(AnchorPane anchor, Region object, int X, int Y, int width, int height){
		object.setLayoutX(X);
		object.setLayoutY(Y);
		object.setPrefWidth(width);
		object.setPrefHeight(height);
		anchor.getChildren().add(object);
	}
	
	public void resize(Region object, int width, int height){

		
		object.setPrefWidth(width);
		object.setPrefHeight(height);
		
	}
	
	

	public void wallnum(AnchorPane anchor,int z){
	    wallbox = new VBox[z+1]; 
	    Wallnum = new Label[z+1]; 
	    health = new Label[z+1]; 
	    danger = new Label[z+1]; 
	    lanes = new Pane[z+1];
	    WeaponImage = new VBox[z+1];
	    for (int i = 1; i < z+1; i++) {
	    	
	        Wallnum[i] = new Label("wall"+i);
	        health[i] = new Label("health"+i);
	        danger[i] = new Label("danger"+i);
	        wallbox[i] = new VBox();
	        WeaponImage[i] = new VBox();
	        WeaponImage[i].setStyle("-fx-background-color: #ffffff;");
	        wallbox[i].setStyle("-fx-background-color: #ffffff;");
	        lanes[i] = new Pane();
	        lanes[i].setStyle("-fx-background-color: #ffffff;");
	        lanes[i].setPrefHeight(100);
	        lanes[i].setPrefWidth(300);
	        WeaponImage[i].setPrefHeight(100);
	        WeaponImage[i].setPrefWidth(100);
	        
	        
	        double g = i*125; 
	        double b =110;
	        AnchorPane.setTopAnchor(WeaponImage[i], g);
	        AnchorPane.setLeftAnchor(WeaponImage[i], b);
	        anchor.getChildren().add(WeaponImage[i]);
	        
	        

	        wallbox[i].getChildren().addAll(Wallnum[i], health[i], danger[i]);
	        double r = i*125; 
	        double t =250;
	        AnchorPane.setTopAnchor(lanes[i], r);
	        AnchorPane.setLeftAnchor(lanes[i], t);
	        anchor.getChildren().add(lanes[i]);
	       
	        
	        double f = i * 125; 
	        double c = i * 50; 
	        AnchorPane.setTopAnchor(wallbox[i], f);
	       
	        anchor.getChildren().addAll(wallbox[i]);
	        
	    }
	    }
		
	public  VBox walls(Label num, Label danger, Label hp){
		VBox temp=  new VBox();
		temp.getChildren().add(num);
		temp.getChildren().add(danger);
		temp.getChildren().add(hp);
		return temp;
	}
	
	public void start(Stage primaryStage) {
	    try {
	    	
	    	primaryStage.setTitle("AOT");
	    	 Image icon = new Image("icon.png");
	    	 primaryStage.getIcons().add(icon);
	    	 primaryStage.setFullScreen(true);
	    	 
	    	 
	    	ToggleGroup mode = new ToggleGroup();
	        EASY = new RadioButton("EasyMode");
	        HARD = new RadioButton("HardMode");
	        EASY.setToggleGroup(mode);
	        HARD.setToggleGroup(mode);
	        PlayGame = new Button("PlayGame");
	        About = new Button("About");
	        PiercingCannon= new Button("Anti-Titan Shell"+"\n"+"Type:PiercingCannon"+"\n" +" price=25"+"\n" + "damage=10");
	        WallTrap= new Button("Proximity Trap"+"\n"+"Type:Wall Trap"+"\n" +" price=75"+ "\n" +"damage=100");
	        SniperCannon =new Button("Long Range Spear"+"\n" +"Type:Sniper Cannon"+"\n"+" price=25"+ "\n" +"damage=35");
	        VolleySpreadCannon = new Button("Wall Spread Cannon"+"\n"+"Type:Volley Spread Cannon" +"\n"+" price=100"+ "\n" +"damage=5");
	        desc = new Label("This is our humble game that inspects the great war between the titans and humans trying to defend themselves behind the walls of paradise, you can play easy(3 walls) or hard(5 walls),you choose what to do with your limited resources to buy which weapon to put at any wall of your choice to defend your people, each turn titans move towards the wall if any titan reach a wall it causes damage that decreases the wall health , danger levels increase depending on the number and type of titans at each wall with each titan and weapon having their own unique abilities.");
	        desc.setWrapText(true);
	        backplay = new Button("back to game");
	        Home = new AnchorPane();
	        AboutPage = new AnchorPane();
	        WeaponPage= new AnchorPane();
	        EasyPage= new AnchorPane();
	        HardPage =new AnchorPane();
	        PassTurn= new Button("PASS TURN");
	        
	        lanechoice = new ComboBox<String>();
	        lanechoice.setPromptText("please choose a lane");
	        
	        Image backgroundImage = new Image("attack-on-titan.jpeg");
	        ImageView imageView = new ImageView(backgroundImage);
	        Home.getChildren().add(imageView);
	       
	        
	        
	        
	        
	        
	        
	        score = new Label("score");
	        turn =  new Label("turn");
	        phase =  new Label("phase");
	        resources =  new Label("resources");
	        info = new VBox();
	        info.getChildren().add(score);
	        info.getChildren().add(turn);
	        info.getChildren().add(phase);
	        info.getChildren().add(resources);
	        AnchorPane.setTopAnchor(info, 800.0);
	        
	        
	        info.setMaxWidth(150.0);
	        
	        info.setStyle("-fx-background-color: #ffffff;");
	        
	        Image backgroundImage3 = new Image("des.jpg");
	        ImageView imageView3 = new ImageView(backgroundImage3);
	        AboutPage.getChildren().add(imageView3);
	        
	        Image backgroundImage4 = new Image("weaponbackground.jpg");
	        ImageView imageView4 = new ImageView(backgroundImage4);
	        WeaponPage.getChildren().add(imageView4);
	 

	        VBox vbox = new VBox();
	        VBox descbox = new VBox();
	        
	        VBox over = new VBox();
	        
	        
	        Button BackToHome = new Button("Back To Home");
	        
	        Label GameOverText = new Label("GAME OVER");
	        Label finalScore = new Label("Final Score");
	        GameOverText.setStyle("-fx-font-size: 30px;");
	        
	       
	       
	        
	       
	        
	        over.getChildren().addAll(GameOverText,finalScore,BackToHome);
	       
	      
	        descbox.setMaxWidth(1000.0);;
	        Scene scene = new Scene(Home, 400, 400);
	        descbox.getChildren().add(desc);
	        back= new Button("back");
	        descbox.setStyle("-fx-background-color: #ffffff;");
	        weaponButton = new Button("Weapons");
	        weaponbox=new VBox();
	        weaponbox.setAlignment(Pos.CENTER);
	        weaponbox.getChildren().add(PiercingCannon);
	        weaponbox.getChildren().add(WallTrap);
	        weaponbox.getChildren().add(SniperCannon);
	        weaponbox.getChildren().add(VolleySpreadCannon);
	        AnchorPane.setLeftAnchor(weaponbox, 300.0);
	        AnchorPane.setTopAnchor(weaponbox, 300.0);
	        WeaponPage.getChildren().addAll(weaponbox,info);
	       
	      
	
	    	
	    
	        
	        
	        AnchorPane.setTopAnchor(backplay, 500.0);
	        AnchorPane.setLeftAnchor(backplay, 50.0);  
	        
	        
	        vbox.setAlignment(Pos.CENTER); 
	        vbox.getChildren().add(PlayGame);
	        vbox.getChildren().add(EASY);
	        vbox.getChildren().add(HARD);
	        vbox.getChildren().add(About);
	        resize(PlayGame,300,100);
	        descbox.setLayoutX(500);
	        descbox.setLayoutY(800);
	        
	        
	        AnchorPane.setTopAnchor(vbox, 0.0);
	        AnchorPane.setBottomAnchor(vbox, 0.0);
	        AnchorPane.setLeftAnchor(vbox, 0.0);
	        AnchorPane.setRightAnchor(vbox, 0.0);
	        Home.getChildren().add(vbox);
	        AboutPage.getChildren().add(descbox);
	        AboutPage.getChildren().add(back);
	        
	        GameOver = new AnchorPane();
	        over.setAlignment(Pos.CENTER);
	        adder(GameOver,over,700,300,500,500);
	        

	        GameOverScene = new Scene(GameOver);
	        

	        AboutScene = new Scene(AboutPage, 400,400);
	        WeaponScene = new Scene(WeaponPage, 400,400);
	        EasyPage = new AnchorPane();
	        easyScene = new Scene(EasyPage, 400, 400); 
	         HardPage = new AnchorPane();
	        hardScene = new Scene(HardPage, 400, 400); 
	        
	        

	        WeaponPage.getChildren().add(backplay);
	        AnchorPane.setTopAnchor(backplay, 0.0);
	       
	        AnchorPane.setLeftAnchor(backplay, 0.0);
	        
	        VBox combo = new VBox(lanechoice);
	        Image backgroundImage1 = new Image("Attack+on+Titan.jpeg");
	        ImageView imageView1 = new ImageView(backgroundImage1);
	        EasyPage.getChildren().add(imageView1);
	        Image backgroundImage2 = new Image("Attack+on+Titan.jpeg");
	        ImageView imageView2 = new ImageView(backgroundImage2);
	        HardPage.getChildren().add(imageView2);
	
	        
	       

	        PlayGame.setOnAction(e -> {
	            if (EASY.isSelected()) {
	            	z=3;
	            	
	                primaryStage.setScene(easyScene);
	                primaryStage.setFullScreen(true);
	                EasyPage.getChildren().add(weaponButton);
	                EasyPage.getChildren().add(info);
	                adder(EasyPage,PassTurn,700,600,150,150);
	                lanechoice.getItems().addAll("Lane 1","Lane 2","Lane 3" );
	                adder(WeaponPage,lanechoice,200,200,250,90);
	                 previousScene = primaryStage.getScene();
	               
	                
	                try {
						battle = new Battle(1,0,200,3,250);
						resources.setText("Resources="+battle.getResourcesGathered());
						score.setText("Score="+battle.getScore());
						turn.setText("Turn="+battle.getNumberOfTurns());
						phase.setText("Phase="+battle.getBattlePhase());
						
						wallnum(EasyPage,3);
						
						
						
						 
			                
						
					
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
	            	

	            } else if (HARD.isSelected()) {
	            	z=5;
	                primaryStage.setScene(hardScene);
	                primaryStage.setFullScreen(true);
	                HardPage.getChildren().add(weaponButton);
	                HardPage.getChildren().add(info);
	                adder(HardPage,PassTurn,700,600,150,150);	          
	                lanechoice.getItems().addAll("Lane 1","Lane 2","Lane 3" ,"Lane 4" ,"Lane 5" );
	                adder(WeaponPage,lanechoice,200,200,90,90);
	                
	               
	               previousScene = primaryStage.getScene();
	               
	         
	            try {
					battle = new Battle(1,0,200,5,125);
					resources.setText("Resources="+battle.getResourcesGathered());
					score.setText("Score="+battle.getScore());
					turn.setText("Turn="+battle.getNumberOfTurns());
					phase.setText("Phase="+battle.getBattlePhase());
					 wallnum(HardPage,5);
					
					
				
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	            
	            }});
	        
	        PassTurn.setOnAction(event -> {
	        	
	            battle.passTurn();
	            turn.setText("Turn="+battle.getNumberOfTurns());
	            resources.setText("Resources="+battle.getResourcesGathered());
				score.setText("Score="+battle.getScore());
				phase.setText("Phase="+battle.getBattlePhase());
				battleHander(battle);
				
				if(battle.isGameOver()){
					
					primaryStage.setScene(GameOverScene);
	                primaryStage.setFullScreen(true);
	                finalScore.setText("Your Final Score = "+battle.getScore());
				}
				
	        });
	        
	        About.setOnAction(event ->{ 
	        	primaryStage.setScene(AboutScene);
	        	primaryStage.setFullScreen(true);
	        	});
	        back.setOnAction(event->{
	        	
	        primaryStage.setScene(scene);
	        primaryStage.setFullScreen(true);
	        });
	        backplay.setOnAction(event->{ 
	        	primaryStage.setScene(this.previousScene);
	        	primaryStage.setFullScreen(true);
	        	});

	        weaponButton.setOnAction(event-> {
	        	primaryStage.setScene(WeaponScene);
	        	primaryStage.setFullScreen(true);
	        });
	        lanechoice.setOnAction(event -> {
                
	        	laneforweapon = lanechoice.getValue();
            });
	        PiercingCannon.setOnAction(event -> {
	        	weaponHandler(1,laneforweapon);
	        	turn.setText("Turn="+battle.getNumberOfTurns());
	            resources.setText("Resources="+battle.getResourcesGathered());
				score.setText("Score="+battle.getScore());
				phase.setText("Phase="+battle.getBattlePhase());
				battleHander(battle);
				
	        });
	        WallTrap.setOnAction(event -> {
	        	weaponHandler(2,laneforweapon);
	        	turn.setText("Turn="+battle.getNumberOfTurns());
	            resources.setText("Resources="+battle.getResourcesGathered());
				score.setText("Score="+battle.getScore());
				phase.setText("Phase="+battle.getBattlePhase());
				battleHander(battle);
	        });
	        SniperCannon.setOnAction(event -> {
	        	weaponHandler(3,laneforweapon);
	        	turn.setText("Turn="+battle.getNumberOfTurns());
	            resources.setText("Resources="+battle.getResourcesGathered());
				score.setText("Score="+battle.getScore());
				phase.setText("Phase="+battle.getBattlePhase());
				battleHander(battle);
	        });
	        VolleySpreadCannon.setOnAction(event -> {
	        	weaponHandler(4,laneforweapon);
	        	turn.setText("Turn="+battle.getNumberOfTurns());
	            resources.setText("Resources="+battle.getResourcesGathered());
				score.setText("Score="+battle.getScore());
				phase.setText("Phase="+battle.getBattlePhase());
				battleHander(battle);
	        });
	        BackToHome.setOnAction(event->{
	        	primaryStage.setScene(scene);
	        	primaryStage.setFullScreen(true);
	        });
	        
	        
	        
	        
	        
	        scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
	        primaryStage.setScene(scene);
	        primaryStage.show();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
		

	public static void main(String[] args) {
		launch(args);
	}
}
